export interface Person {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'other';
  birthDate?: string;
  deathDate?: string;
  parentId?: string | null;
  spouseId?: string | null;
  photo?: string;
  notes?: string;
}

export interface FamilyTreeNode {
  person: Person;
  children: FamilyTreeNode[];
  spouse?: Person;
}
