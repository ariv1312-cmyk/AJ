import { Person } from '../types';
import { X, User, Calendar, MessageSquare, Save } from 'lucide-react';
import { useState, useEffect } from 'react';

interface AddPersonModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (person: Omit<Person, 'id'> & { id?: string }) => void;
  onDelete?: (id: string) => void;
  editPerson?: Person | null;
  defaultParentId?: string | null;
  familyMembers: Person[];
}

export default function AddPersonModal({
  isOpen,
  onClose,
  onSave,
  onDelete,
  editPerson,
  defaultParentId,
  familyMembers,
}: AddPersonModalProps) {
  const [name, setName] = useState('');
  const [gender, setGender] = useState<'male' | 'female' | 'other'>('male');
  const [birthDate, setBirthDate] = useState('');
  const [deathDate, setDeathDate] = useState('');
  const [parentId, setParentId] = useState<string | null>(null);
  const [spouseId, setSpouseId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    if (editPerson) {
      setName(editPerson.name);
      setGender(editPerson.gender);
      setBirthDate(editPerson.birthDate || '');
      setDeathDate(editPerson.deathDate || '');
      setParentId(editPerson.parentId || null);
      setSpouseId(editPerson.spouseId || null);
      setNotes(editPerson.notes || '');
    } else {
      setName('');
      setGender('male');
      setBirthDate('');
      setDeathDate('');
      setParentId(defaultParentId || null);
      setSpouseId(null);
      setNotes('');
    }
  }, [editPerson, defaultParentId, isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const personData = {
      ...(editPerson ? { id: editPerson.id } : {}),
      name: name.trim(),
      gender,
      birthDate: birthDate || undefined,
      deathDate: deathDate || undefined,
      parentId,
      spouseId,
      notes: notes.trim() || undefined,
    };

    onSave(personData);
    onClose();
  };

  const handleDelete = () => {
    if (editPerson && onDelete) {
      onDelete(editPerson.id);
      onClose();
    }
  };

  const availableParents = familyMembers.filter(
    (m) => !editPerson || m.id !== editPerson.id
  );

  const availableSpouses = familyMembers.filter(
    (m) => (!editPerson || m.id !== editPerson.id) && !m.spouseId
  );

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-scaleIn"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-800">
            {editPerson ? 'Edit Family Member' : 'Add Family Member'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
              <User className="w-4 h-4" />
              Full Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter full name"
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all"
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Gender</label>
            <div className="flex gap-3">
              {(['male', 'female', 'other'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGender(g)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all ${
                    gender === g
                      ? g === 'male'
                        ? 'bg-blue-500 text-white shadow-md'
                        : g === 'female'
                        ? 'bg-pink-500 text-white shadow-md'
                        : 'bg-purple-500 text-white shadow-md'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {g === 'male' ? '♂ Male' : g === 'female' ? '♀ Female' : '⚧ Other'}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
                <Calendar className="w-4 h-4" />
                Birth Date
              </label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 mb-1 block">Death Date</label>
              <input
                type="date"
                value={deathDate}
                onChange={(e) => setDeathDate(e.target.value)}
                className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Parent</label>
            <select
              value={parentId || ''}
              onChange={(e) => setParentId(e.target.value || null)}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all"
            >
              <option value="">None (Root member)</option>
              {availableParents.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700 mb-1 block">Spouse</label>
            <select
              value={spouseId || ''}
              onChange={(e) => setSpouseId(e.target.value || null)}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all"
            >
              <option value="">None</option>
              {availableSpouses.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-1">
              <MessageSquare className="w-4 h-4" />
              Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any notes about this family member..."
              rows={3}
              className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent outline-none transition-all resize-none"
            />
          </div>

          <div className="flex gap-3 pt-4">
            {editPerson && onDelete && (
              <button
                type="button"
                onClick={handleDelete}
                className="px-4 py-2.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-xl font-medium transition-colors"
              >
                Delete
              </button>
            )}
            <div className="flex-1" />
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 bg-gray-100 text-gray-600 hover:bg-gray-200 rounded-xl font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-medium hover:from-blue-600 hover:to-blue-700 transition-all shadow-md"
            >
              <Save className="w-4 h-4" />
              {editPerson ? 'Update' : 'Add'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
