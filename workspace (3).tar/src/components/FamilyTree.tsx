import { Person } from '../types';
import PersonNode from './PersonNode';

interface FamilyTreeProps {
  members: Person[];
  onSelectPerson: (person: Person) => void;
  onAddChild: (parent: Person) => void;
  onEditPerson: (person: Person) => void;
  selectedPersonId: string | null;
}

interface TreeNode {
  person: Person;
  spouse?: Person;
  children: TreeNode[];
}

function buildTree(members: Person[]): TreeNode[] {
  const memberMap = new Map<string, Person>();
  members.forEach((m) => memberMap.set(m.id, m));

  // Find root members (no parent)
  const roots = members.filter((m) => !m.parentId);

  // Remove spouses from roots (they'll be shown with their partner)
  const spouseIds = new Set(members.filter((m) => m.spouseId).map((m) => m.spouseId!));
  const rootPersons = roots.filter((r) => !spouseIds.has(r.id) || r.spouseId);

  // Deduplicate - only keep one of each couple at root level
  const processedIds = new Set<string>();
  const uniqueRoots: Person[] = [];
  
  for (const root of rootPersons) {
    if (processedIds.has(root.id)) continue;
    uniqueRoots.push(root);
    processedIds.add(root.id);
    if (root.spouseId) {
      processedIds.add(root.spouseId);
    }
  }

  function buildNode(person: Person): TreeNode {
    const spouse = person.spouseId ? memberMap.get(person.spouseId) : undefined;
    
    // Find children of this person or their spouse
    const children = members.filter((m) => {
      if (m.parentId === person.id) return true;
      if (spouse && m.parentId === spouse.id) return true;
      return false;
    });

    // Deduplicate children (avoid showing same child twice)
    const processedChildren = new Set<string>();
    const uniqueChildren: TreeNode[] = [];
    
    for (const child of children) {
      if (processedChildren.has(child.id)) continue;
      processedChildren.add(child.id);
      uniqueChildren.push(buildNode(child));
      if (child.spouseId) {
        processedChildren.add(child.spouseId);
      }
    }

    return {
      person,
      spouse,
      children: uniqueChildren,
    };
  }

  return uniqueRoots.map(buildNode);
}

function TreeNodeComponent({
  node,
  onSelectPerson,
  onAddChild,
  onEditPerson,
  selectedPersonId,
}: {
  node: TreeNode;
  onSelectPerson: (person: Person) => void;
  onAddChild: (parent: Person) => void;
  onEditPerson: (person: Person) => void;
  selectedPersonId: string | null;
}) {
  return (
    <div className="flex flex-col items-center">
      <PersonNode
        person={node.person}
        spouse={node.spouse}
        onSelect={onSelectPerson}
        onAddChild={onAddChild}
        onEdit={onEditPerson}
        isSelected={selectedPersonId === node.person.id || (node.spouse ? selectedPersonId === node.spouse.id : false)}
      />
      
      {node.children.length > 0 && (
        <>
          {/* Vertical line down */}
          <div className="w-0.5 h-8 bg-gradient-to-b from-gray-300 to-gray-400" />
          
          {/* Horizontal connector line */}
          {node.children.length > 1 && (
            <div className="relative w-full flex justify-center">
              <div
                className="absolute top-0 h-0.5 bg-gray-300"
                style={{
                  left: `${100 / (node.children.length * 2)}%`,
                  right: `${100 / (node.children.length * 2)}%`,
                }}
              />
            </div>
          )}
          
          {/* Children */}
          <div className="flex gap-8 mt-0">
            {node.children.map((child) => (
              <div key={child.person.id} className="flex flex-col items-center">
                {/* Vertical line to child */}
                <div className="w-0.5 h-8 bg-gray-300" />
                <TreeNodeComponent
                  node={child}
                  onSelectPerson={onSelectPerson}
                  onAddChild={onAddChild}
                  onEditPerson={onEditPerson}
                  selectedPersonId={selectedPersonId}
                />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function FamilyTree({
  members,
  onSelectPerson,
  onAddChild,
  onEditPerson,
  selectedPersonId,
}: FamilyTreeProps) {
  const tree = buildTree(members);

  if (members.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center animate-fadeIn">
        <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-6">
          <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
        </div>
        <h3 className="text-xl font-semibold text-gray-600 mb-2">No Family Members Yet</h3>
        <p className="text-gray-400 max-w-sm">
          Start building your family tree by adding the first member. Click the "Add Member" button above to begin.
        </p>
      </div>
    );
  }

  return (
    <div className="flex justify-center py-8 px-4 overflow-x-auto animate-fadeIn">
      <div className="flex gap-12 items-start">
        {tree.map((node) => (
          <TreeNodeComponent
            key={node.person.id}
            node={node}
            onSelectPerson={onSelectPerson}
            onAddChild={onAddChild}
            onEditPerson={onEditPerson}
            selectedPersonId={selectedPersonId}
          />
        ))}
      </div>
    </div>
  );
}
