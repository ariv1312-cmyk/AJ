import { Person } from '../types';
import { User, Heart, Calendar, MessageSquare } from 'lucide-react';

interface PersonNodeProps {
  person: Person;
  spouse?: Person;
  onSelect: (person: Person) => void;
  onAddChild: (person: Person) => void;
  onEdit: (person: Person) => void;
  isSelected: boolean;
}

export default function PersonNode({ person, spouse, onSelect, onAddChild, onEdit, isSelected }: PersonNodeProps) {
  const getGenderColor = (gender: string) => {
    switch (gender) {
      case 'male':
        return 'from-blue-400 to-blue-600';
      case 'female':
        return 'from-pink-400 to-pink-600';
      default:
        return 'from-purple-400 to-purple-600';
    }
  };

  const getGenderBorder = (gender: string) => {
    switch (gender) {
      case 'male':
        return 'border-blue-300';
      case 'female':
        return 'border-pink-300';
      default:
        return 'border-purple-300';
    }
  };

  const getGenderBg = (gender: string) => {
    switch (gender) {
      case 'male':
        return 'bg-blue-50';
      case 'female':
        return 'bg-pink-50';
      default:
        return 'bg-purple-50';
    }
  };

  const calculateAge = (birthDate?: string, deathDate?: string) => {
    if (!birthDate) return null;
    const birth = new Date(birthDate);
    const end = deathDate ? new Date(deathDate) : new Date();
    let age = end.getFullYear() - birth.getFullYear();
    const monthDiff = end.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && end.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const renderPersonCard = (p: Person, isSpouse: boolean = false) => {
    const age = calculateAge(p.birthDate, p.deathDate);
    const isDeceased = !!p.deathDate;

    return (
      <div
        key={p.id}
        className={`relative cursor-pointer rounded-xl border-2 ${getGenderBorder(p.gender)} ${getGenderBg(p.gender)} shadow-lg p-4 min-w-[160px] max-w-[200px] transition-all duration-300 hover:scale-105 hover:-translate-y-1 ${
          isSelected && !isSpouse ? 'ring-4 ring-amber-400/75' : ''
        } ${isDeceased ? 'opacity-80' : ''}`}
        onClick={() => onSelect(p)}
      >
        {isDeceased && (
          <div className="absolute -top-2 -right-2 bg-gray-500 text-white text-xs px-2 py-0.5 rounded-full">
            ✝
          </div>
        )}
        
        <div className="flex flex-col items-center text-center">
          <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${getGenderColor(p.gender)} flex items-center justify-center mb-2 shadow-md`}>
            <User className="w-6 h-6 text-white" />
          </div>
          
          <h3 className="font-semibold text-gray-800 text-sm leading-tight">{p.name}</h3>
          
          {age !== null && (
            <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {isDeceased ? `Lived ${age} yrs` : `${age} yrs`}
            </p>
          )}
          
          {p.notes && (
            <p className="text-xs text-gray-400 mt-1 truncate max-w-full flex items-center gap-1">
              <MessageSquare className="w-3 h-3 flex-shrink-0" />
              <span className="truncate">{p.notes}</span>
            </p>
          )}
        </div>

        {!isSpouse && (
          <div className="flex gap-1 mt-3 justify-center">
            <button
              onClick={(e) => { e.stopPropagation(); onEdit(p); }}
              className="text-xs px-2 py-1 bg-white/80 hover:bg-white rounded-md text-gray-600 hover:text-gray-800 transition-colors border border-gray-200"
            >
              Edit
            </button>
            <button
              onClick={(e) => { e.stopPropagation(); onAddChild(p); }}
              className="text-xs px-2 py-1 bg-white/80 hover:bg-white rounded-md text-gray-600 hover:text-gray-800 transition-colors border border-gray-200"
            >
              + Child
            </button>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col items-center">
      <div className="flex items-center gap-2">
        {renderPersonCard(person)}
        {spouse && (
          <>
            <div className="flex items-center">
              <Heart className="w-5 h-5 text-red-400 fill-red-400 mx-1" />
            </div>
            {renderPersonCard(spouse, true)}
          </>
        )}
      </div>
    </div>
  );
}
