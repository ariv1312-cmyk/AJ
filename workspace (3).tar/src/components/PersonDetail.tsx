import { Person } from '../types';
import { X, Calendar, Heart, Users, MessageSquare, User } from 'lucide-react';

interface PersonDetailProps {
  person: Person | null;
  familyMembers: Person[];
  onClose: () => void;
  onEdit: (person: Person) => void;
}

export default function PersonDetail({ person, familyMembers, onClose, onEdit }: PersonDetailProps) {
  if (!person) return null;

  const parent = person.parentId ? familyMembers.find((m) => m.id === person.parentId) : null;
  const spouse = person.spouseId ? familyMembers.find((m) => m.id === person.spouseId) : null;
  const children = familyMembers.filter(
    (m) => m.parentId === person.id || (spouse && m.parentId === spouse.id)
  );
  const siblings = familyMembers.filter(
    (m) => m.id !== person.id && m.parentId === person.parentId && person.parentId
  );

  const getGenderIcon = (gender: string) => {
    switch (gender) {
      case 'male': return '♂';
      case 'female': return '♀';
      default: return '⚧';
    }
  };

  const getGenderColor = (gender: string) => {
    switch (gender) {
      case 'male': return 'text-blue-500';
      case 'female': return 'text-pink-500';
      default: return 'text-purple-500';
    }
  };

  const calculateAge = () => {
    if (!person.birthDate) return null;
    const birth = new Date(person.birthDate);
    const end = person.deathDate ? new Date(person.deathDate) : new Date();
    let age = end.getFullYear() - birth.getFullYear();
    const monthDiff = end.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && end.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const age = calculateAge();

  return (
    <div className="fixed right-0 top-0 h-full w-80 bg-white shadow-2xl z-40 overflow-y-auto border-l border-gray-100 animate-slideIn">
      <div className="p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-gray-800">Details</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Profile */}
        <div className="text-center mb-6">
          <div className={`w-20 h-20 mx-auto rounded-full bg-gradient-to-br ${
            person.gender === 'male' ? 'from-blue-400 to-blue-600' :
            person.gender === 'female' ? 'from-pink-400 to-pink-600' :
            'from-purple-400 to-purple-600'
          } flex items-center justify-center shadow-lg mb-3`}>
            <User className="w-10 h-10 text-white" />
          </div>
          <h3 className="text-xl font-bold text-gray-800">{person.name}</h3>
          <span className={`text-2xl ${getGenderColor(person.gender)}`}>
            {getGenderIcon(person.gender)}
          </span>
          {age !== null && (
            <p className="text-sm text-gray-500 mt-1">
              {person.deathDate ? `Lived ${age} years` : `Age: ${age}`}
            </p>
          )}
        </div>

        {/* Info */}
        <div className="space-y-3 mb-6">
          {person.birthDate && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <Calendar className="w-5 h-5 text-gray-400" />
              <div>
                <p className="text-xs text-gray-400">Born</p>
                <p className="text-sm font-medium text-gray-700">
                  {new Date(person.birthDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            </div>
          )}
          
          {person.deathDate && (
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              <Calendar className="w-5 h-5 text-gray-400" />
              <div>
                <p className="text-xs text-gray-400">Died</p>
                <p className="text-sm font-medium text-gray-700">
                  {new Date(person.deathDate).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            </div>
          )}

          {person.notes && (
            <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-xl">
              <MessageSquare className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-xs text-gray-400">Notes</p>
                <p className="text-sm text-gray-700">{person.notes}</p>
              </div>
            </div>
          )}
        </div>

        {/* Relationships */}
        <div className="space-y-4">
          {parent && (
            <div>
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                <User className="w-3 h-3" /> Parent
              </h4>
              <div className="p-2.5 bg-blue-50 rounded-lg text-sm text-blue-700 font-medium">
                {parent.name}
              </div>
            </div>
          )}

          {spouse && (
            <div>
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Heart className="w-3 h-3" /> Spouse
              </h4>
              <div className="p-2.5 bg-pink-50 rounded-lg text-sm text-pink-700 font-medium">
                {spouse.name}
              </div>
            </div>
          )}

          {children.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Users className="w-3 h-3" /> Children ({children.length})
              </h4>
              <div className="space-y-1.5">
                {children.map((child) => (
                  <div key={child.id} className="p-2.5 bg-green-50 rounded-lg text-sm text-green-700 font-medium">
                    {child.gender === 'male' ? '♂' : '♀'} {child.name}
                  </div>
                ))}
              </div>
            </div>
          )}

          {siblings.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-1">
                <Users className="w-3 h-3" /> Siblings ({siblings.length})
              </h4>
              <div className="space-y-1.5">
                {siblings.map((sibling) => (
                  <div key={sibling.id} className="p-2.5 bg-amber-50 rounded-lg text-sm text-amber-700 font-medium">
                    {sibling.gender === 'male' ? '♂' : '♀'} {sibling.name}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Edit Button */}
        <button
          onClick={() => onEdit(person)}
          className="w-full mt-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl font-medium hover:from-blue-600 hover:to-blue-700 transition-all shadow-md"
        >
          Edit Profile
        </button>
      </div>
    </div>
  );
}
